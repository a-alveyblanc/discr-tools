import numpy as np
import numpy.linalg as la


def conjugate_gradient(discr, b, maxiters=1000, tol=1e-8):
    pass
