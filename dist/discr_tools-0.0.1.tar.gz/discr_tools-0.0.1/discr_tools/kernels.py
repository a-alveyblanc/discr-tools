import loopy as lp


def gradient_3d(queue, operator, vec, metrics):
    """
    Register tiled gradient operator.
    """

    nel, np = vec.shape
    np1d = int(np) ** (1/3)

    u = vec.reshape(-1, np1d, np1d, np1d, order="F")
    metrics = metrics.reshape(3, 3, -1, np1d, np1d, np1d, order="F")
    grad_u = np.zeros((3, nel, np)).reshape(3, nel, np1d, np1d, np1d, order="F")

    knl = lp.make_kernel(
        f"{{ [e, x, y, z] : 0 <= x, y, z < {np1d} and 0 <= e < {nel} }}",
        [
            # create temporaries to hold non-parallelized dimension
            "".join(f"<> z{i} = u[e, i, j, {i}]\n" for i in range(np1d)),

            # apply operator to scalars of non-parallelized dimension
            "".join(
                f"ut{i}(e, i, j, k) := d[k,{i}] * z{i}\n"
                for i in range(np1d)
            ),

            # reference partials
            """
            ur(e, i, j, k) := sum([l], d[i,l] * u[e,l,j,k])
            us(e, i, j, k) := sum([l], d[j,l] * u[e,i,l,k])
            """,
            "ut(e, i, j, k) := ".join(
                f"ut{i}(e, i, j, k) + " for i in range(np1d-1)
            ) + f"ut{np1d-1}(e, i, j, k)",

            # metric term substitution rules
            """
            drdx(e, i, j, k) := G[e, 0, 0, i, j, k]
            dsdx(e, i, j, k) := G[e, 0, 1, i, j, k]
            dtdx(e, i, j, k) := G[e, 0, 2, i, j, k]

            drdy(e, i, j, k) := G[e, 1, 0, i, j, k]
            dsdy(e, i, j, k) := G[e, 1, 1, i, j, k]
            dtdy(e, i, j, k) := G[e, 1, 2, i, j, k]

            drdz(e, i, j, k) := G[e, 2, 0, i, j, k]
            dsdz(e, i, j, k) := G[e, 2, 1, i, j, k]
            dtdz(e, i, j, k) := G[e, 2, 2, i, j, k]
            """

            # apply chain rule and store
            """
            du[0, e, i, j, k] = ur(e, i, j, k) * drdx(e, i, j, k) + \
                                us(e, i, j, k) * dsdx(e, i, j, k) + \
                                ut(e, i, j, k) * dtdx(e, i, j, k)

            du[1, e, i, j, k] = ur(e, i, j, k) * drdy(e, i, j, k) + \
                                us(e, i, j, k) * dsdy(e, i, j, k) + \
                                ut(e, i, j, k) * dtdy(e, i, j, k)

            du[2, e, i, j, k] = ur(e, i, j, k) * drdz(e, i, j, k) + \
                                us(e, i, j, k) * dsdz(e, i, j, k) + \
                                ut(e, i, j, k) * dtdz(e, i, j, k)
            """
        ],
        [
            lp.GlobalArg("u",
                         dim_tags=("N3, N0, N1, N2"),
                         shape=u.shape,
                         dtype=u.dtype,
                         is_input=True),
            lp.GlobalArg("d",
                         shape=operator.shape,
                         dtype=operator.dtype,
                         is_input=True),
            lp.GlobalArg("du",
                         dim_tags=("N4, N3, N0, N1, N2"),
                         shape=grad_u.shape,
                         dtype=grad_u.dtype,
                         is_output=True),
            lp.GlobalArg("G",
                         dim_tags=("N5, N4, N3, N0, N1, N2"),
                         shape=metrics.shape,
                         dtype=metrics.dtype)
        ]
    )

    knl_exec = knl.executor()
    evt, grad_u = knl_exec(queue, u=vec, d=operator, du=grad_u, G=metrics)
    evt.wait()

    return grad_u


def divergence_3d(queue, operator, vec):
    pass
