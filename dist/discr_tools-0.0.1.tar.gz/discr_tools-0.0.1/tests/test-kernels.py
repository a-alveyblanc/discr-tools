import discr_tools.geometry as geo
from discr_tools.discretization import Discretization

def test_gradient_3d():
    discr = Discretization(10, -1, 1, 3, 1)
