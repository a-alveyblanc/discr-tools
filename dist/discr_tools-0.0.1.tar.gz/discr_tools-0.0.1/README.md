# discr-tools

Simple implementation of tools that could be used for solving Poisson using SEM/FEM. Things like generating a nodal basis based on GLL/equidistant nodes, generating a simple quad/hex mesh, geometric factors, etc.
